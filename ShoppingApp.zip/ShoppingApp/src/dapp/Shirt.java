/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dapp;

import sapp.Clothing;

/**
 *
 * @author chand
 */
public class Shirt extends Clothing {

    private boolean hasCollar;
    private String handSize;
    private boolean buttoned;
    private boolean hasZipper;

    public Shirt(boolean hasCollar, String handSize, boolean buttoned, boolean hasZipper, float price, int size, String color, String desc, String forGender) {
        super(price, size, color, desc, forGender);
        this.hasCollar = hasCollar;
        this.handSize = handSize;
        this.buttoned = buttoned;
        this.hasZipper = hasZipper;
    }
  
    @Override
    public String toString() {
        return "Shirt{ price = " + this.price + "hasCollar=" + hasCollar + ", handSize=" + handSize + ", buttoned=" + buttoned + ", hasZipper=" + hasZipper + '}';
    }

    
    
    public boolean isHasCollar() {
        return hasCollar;
    }

    public void setHasCollar(boolean hasCollar) {
        this.hasCollar = hasCollar;
    }

    public String getHandSize() {
        return handSize;
    }

    public void setHandSize(String handSize) {
        this.handSize = handSize;
    }

    public boolean isButtoned() {
        return buttoned;
    }

    public void setButtoned(boolean buttoned) {
        this.buttoned = buttoned;
    }

    public boolean isHasZipper() {
        return hasZipper;
    }

    public void setHasZipper(boolean hasZipper) {
        this.hasZipper = hasZipper;
    }
    
 
    public static void main(String [] args){
      //  Shirt s = new Shirt(22f, 42, "Green", "A peice of Clothing", "M");
      //  System.out.println(s);
    }

    @Override
    public boolean stitch() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  
        // implment how to stitch a shirt :=)
    }

    
}
