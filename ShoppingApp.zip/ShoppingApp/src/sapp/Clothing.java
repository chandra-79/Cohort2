package sapp;

import java.util.Objects;

public abstract class Clothing {
      
    protected float price;
    private int size;
    private String color;
    private String desc;
    private String forGender;

    public abstract  boolean stitch ();
    
    
    public String getForGender() {
        return forGender;
    }

    public void setForGender(String forGender) {
        this.forGender = forGender;
    }

    public Clothing(float price, int size, String color, String desc, String forGender) {
        this.price = price;
        this.size = size;
        this.color = color;
        this.desc = desc;
        this.forGender = forGender;
    }

    @Override
    public String toString() {
        return "Clothing{" + "price=" + price + ", size=" + size + ", color=" + color + ", desc=" + desc + ", forGender=" + forGender + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Float.floatToIntBits(this.price);
        hash = 97 * hash + this.size;
        hash = 97 * hash + Objects.hashCode(this.color);
        hash = 97 * hash + Objects.hashCode(this.desc);
        hash = 97 * hash + Objects.hashCode(this.forGender);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Clothing other = (Clothing) obj;
        if (Float.floatToIntBits(this.price) != Float.floatToIntBits(other.price)) {
            return false;
        }
        if (this.size != other.size) {
            return false;
        }
        if (!Objects.equals(this.color, other.color)) {
            return false;
        }
        if (!Objects.equals(this.desc, other.desc)) {
            return false;
        }
        if (!Objects.equals(this.forGender, other.forGender)) {
            return false;
        }
        return true;
    }


    
    
   
    
    
    
    
    
    
    public static void main(String[] args) {
        System.out.println(" From sapp.Clothing::main method");
        
       // Clothing c = new Clothing(90.99f, 42, "Black", "T-Shirt","Female");
       // System.out.println(c);
        
        }

    
    
    
    
    
    
    
    
    
    
    
    
    public float getPrice() {
        return price;
    }
    public void setPrice(float price) {
        if(price > 1000)
            return;
        this.price = price;
    }
    public int getSize() {
        return size;
    }
    public void setSize(int size) {
        int j = 99;
        if (size <= 0 || size >= 55)
            return;
        this.size = size;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public String getDesc() {
        return desc;
    }
    public void setDesc(String desc) {
        this.desc = desc;
    }
    
}
