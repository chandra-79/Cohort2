
package sapp;

import dapp.Shirt;

  
public class Demo {
    public static void main(String [] args){
    
        //Shirt(boolean hasCollar, String handSize, boolean buttoned, boolean hasZipper, float price, int size, String color, String desc, String forGender)
        Shirt s = new Shirt(true, "Full", true, false, 99.99f, 42, "Black", "TShirt", "Unisex");
        
        s.stitch();
        //Clothing c = new Clothing(99.99f, 42, "Black", "TShirt", "Unisex");
        
        
    }
}
