
public class Demo7 {

    public static void main(String[] args) {
        int[] marks = {783, 737, 698, 787, 499};
        String[] subjects = {"Eng", "CS", "MM", "Sci", "Soc"};
        int total = 0, min = 0, max =0, avg = 0;
                
        for (int i = 0; i < marks.length; i++) {
            System.out.println(subjects[i] + " :: " + marks[i]);
            total += marks[i];
            if (i ==0)
                min = max = marks [i];
            else {
                max = marks[i] > max ? marks[i] : max;
                min = marks[i] < min ? marks[i] : min;
            }
        }
        // Find out avg marks, total, min , max values 

        System.out.println(" Total Marks : " + total);
        System.out.println(" Average Marks : " + (total/marks.length));
        System.out.println(" Max of Marks : " + max);
        System.out.println(" Min of Marks : " + min);
    }

}
