
import java.util.Scanner;


public class Demo6 {
    
    static Scanner mis = new Scanner(System.in);
    
    public static int promptInt(String msg){
        System.out.print(msg);
        return mis.nextInt();
    }
    public static void mathTable(int num1, int num2 ){
        for(int cnt =1 ; cnt <= num2 ; cnt++)
            System.out.println( " |  " +  num1 + "  *  " + cnt + "  =  " + (cnt*num1) +  "   | ");
    }    
    public static void main(String[] args) {
        System.out.println(" hello from main !!!! ");
        
        int num1 = promptInt(" Enter 1st Number : ");
        int num2 = promptInt(" Enter 2nd Number : ");
        mathTable(num1, num2);
    }
}
