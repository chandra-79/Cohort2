
public class Demo1 {
    
    public static int  getBigger(int i, int j){
        
        return i > j ? i : j; //  Ternary Operator 
//        if( i > j)
//            return i;
//        else if(j > i)
//            return j;
//        else
//            return i;
    }
    
    public static void print100(){
        int i = 0;
        while (i <= 100) 
            System.out.println("i = " + i++);     
    }
    public static void print100_DoWhile(){
        int i = 0;
        do {
            System.out.println("i = " + i++);     
        }while (i <= 100) ;
    }
    
    public static void print100_UsingFor(){
       for( int i = 0 ; i <= 100; ++i)  // i += 2
        System.out.println("i = " + i++);     
    }
    
    public static void main(String [] args){
        
        System.out.println(" hello from main !!!! ");
//        print100_UsingFor();
        System.out.println(" Bigger value from 10 & 20 " + getBigger(1897,223) );
        System.out.println(" Bigger value from 10 & 20 " + getBigger(234,786) );
//        System.out.println(" Bigger value from 10 & 20 " + getBigger(20,20) );
    }
}
