/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chand
 */
public class Cat {

    private int mood ;
    private int hungry;
    private int energy;
    private boolean alive;
    private String name;
    private float age;
    

    public Cat (int iVal,boolean al, String n, float a){ // Instance Init .....
        hungry = energy = iVal;
        name = n;
        age = a;
        alive = al;
       System.out.println(" Instance Init 1    ......");

    }
    
    
    private void meow() {
        System.out.println(" meow ......");
    }

    public void sleep() {
        energy++;
        hungry++;
    }

    public void play() {
        energy--;
        mood++;
        meow();
    }

    public void feed() {
        mood++;
        hungry--;
        meow();
    }

    public String getStatus() {
        return (" Hungry : " + hungry + " \n Mood : " + mood
                + " \nEnergy : " + energy + " \n Name: " + name
                + " \n Age : " + age + "\n status = " + alive + " \n\n\n");
    }

    public static void main(String[] args) {

        Cat myFavCat = new Cat(9,true, "MyFavCat", 8.8f);
        System.out.println(myFavCat.getStatus());
     
        Cat myFavCat1 = new Cat(5,true, "MyLFCat", 2.8f);
        System.out.println(myFavCat1.getStatus());
     

//Cat myLFCat = new Cat();
//            Cat catThatIHate = new Cat();
//    
    }
}

class otherClasses {

}
