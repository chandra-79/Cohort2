
import java.util.Scanner;


public class Demo8 {
    public static void mathTable(int num1, int num2 ){
        for(int cnt =1 ; cnt <= num2 ; cnt++)
            System.out.println( " |  " +  num1 + "  *  " + cnt + "  =  " + (cnt*num1) +  "   | ");
    }    
    public static void main(String[] args) {
        System.out.println(" hello from main !!!! ");
        
        System.out.println(" Value of i == " + Demo9.i);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
//        System.out.println(" Number of args = " + args.length);
//        int count = 0;
//        for(String s : args)
//            System.out.println(" args["+ count++ + "] = " + s);        
//       mathTable(Integer.parseInt(args[0]),Integer.parseInt(args[1]));
    }
}
