/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chand
 */
public class Demo3 {

    public static void firstMethod() {
        System.out.println();
        System.out.println();
    }

    public static void m2() {
        firstMethod();
        System.out.println();
    }

    public static void m3() {
        firstMethod();
    }

    public static void m4() {
        firstMethod();
        System.out.println();
    }

    public static void main(String[] args) {
        System.out.println(" From Main : Demo 3 Class ");
        System.out.println();
        firstMethod();
    }
}
