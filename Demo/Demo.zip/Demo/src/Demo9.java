
import java.util.Scanner;

public class Demo9 {

    public static Scanner ins = new Scanner(System.in);
    public static int i;
//    static char c = 'X';
//    static boolean b = true;
//
//    static int[] iArray = {1, 2, 3, 4, 5};
//    static int iArray1[] = {1, 2, 3, 4, 5};
//    static int iArray2[][] = {{1, 2, 3, 4, 5}, {1, 2, 3, 4, 5}, {1, 2, 3, 4, 5}, {1, 2, 3, 4, 5}};

    static {
        System.out.print(" Enter a value for i ::: ");
        i = ins.nextInt();
    }

  
}
