﻿using System;

public class SalaryAccount : BankAccount
{
	public SalaryAccount()
	{
	}

    public override string ToString()
    {
        return base.ToString();
    }
}
