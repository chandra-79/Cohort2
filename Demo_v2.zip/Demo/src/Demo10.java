/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chand
 */
public class Demo10 {
      public static void main(String[] args) {
        System.out.println("      hello from Demo10::main method !!!! ");
       
        
        String str = "      This is a string     ";
        
        System.out.println(" Str as it is :: " + str);
        str = str.toUpperCase();
        System.out.println(" Str upper case :: " + str);
        str = str.toLowerCase();
        System.out.println(" Str lower case :: " + str);
        str = str.trim();
        System.out.println(" Str as it is :: " + str);
        for(String s:str.split(" "))
            System.out.println(s);
                
      }
}
