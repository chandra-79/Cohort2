
public class Demo5 {

    public static void m1(int i) {

        switch(i){
            case 1: System.out.println("One");break;
            case 2: System.out.println("Two");break;
            case 3: System.out.println("Three");break;
            case 4: System.out.println("Four");break;
            case 5: System.out.println("Five");break;
            default : System.out.println("Others");
        }

    }

    public static void main(String[] args) {
        System.out.println(" hello from main !!!! ");
        m1(1);
    }
}