
public class Demo13 {
    
 
    /// add("hello", "world")
    
    public static void main(String [] args ){

                System.out.println(" From Demo13::main Method ");

        
        for(var s : args)
            System.out.println(s);
        
        var i = 10;
        var str = "this is a string";
        var b = true;
        
        System.out.println(" i = " + i + ", str = " + str + ", b = " + b);
        
        for(var k = 1; k < 100; k++)
            System.out.print(k +  " ");
        
    }
}
