/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chand
 */
public class Demo2 {

    static int i; // Global Variable for this class 
    static boolean b;
    static char c;
    static String s;
    static byte b1;
    static float f;
    public static void m1() { 
        System.out.println(" i = " + i);

        int i = 222;    // Method Level Variable 
        System.out.println(" i = " + i);
        i++;
        System.out.println(" i = " + i);

    }

    public static void m2() {

        System.out.println(" i = " + i);
        i++;
    }

    public static void m3() {

        System.out.println(" i = " + i);
        i++;
    }

    public static void main(String[] args) {
        System.out.println(" From Main : Demo 2 Class ");
        m1();
        m2();
        m3();
        System.out.println(" i = " + i);
    }
}
