
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chand
 */
public class Demo12 {
    public static void main(String [] args){
        
        
        LocalDate d = LocalDate.now();
        LocalDate bd = LocalDate.parse("1991-03-28");
        LocalDateTime dt = LocalDateTime.now();
        
        System.out.println(" Date :: " + bd.getMonth());
        System.out.println(" Date :: " + bd.getDayOfWeek());
        System.out.println(" Date :: " + bd.getDayOfMonth());
        System.out.println(" Date Time :: " + dt);
    }
}
