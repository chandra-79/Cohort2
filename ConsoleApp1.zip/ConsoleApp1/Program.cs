﻿using System;
using System.Threading;

namespace ConsoleApp1
{
    class Program
    {

        static void mathTable() // Traditional For Loop
        {
            Console.Write(" Enter the value for mathematical Table :");
            int i = int.Parse(Console.ReadLine());
            Console.Write(" Enter the value for table upto :");
            int j = int.Parse(Console.ReadLine());
            for (int k = 1; k <= i; k++)
            {
                for (int c = 1; c <= j; c++)
                {
                    Console.WriteLine(k + " * " + c + " = " + k * c);
                }
            }

        }


        // Method Overloading - Polymorphism - One Method [name] but different parameters
        // Making the method Signature Unique, but for end-user it looks like same method
        static int add(int a, int b)
        {
            return a + b;
        }

        static String add(String a, String b)
        {
            return a + b;
        }

        static float add(float a, float b)
        {
            return a + b;
        }

        static void monthDays()
        {
            Console.Write(" Enter Month Name : ");
            String mon = Console.ReadLine();

            switch (mon)
            { // if(mon.equals("Jan") || mon.equals("Mar").........
                case "Jan":
                case "Mar":
                case "May":
                case "Jul":
                case "Aug":
                case "Oct":
                case "Dec":
                    Console.WriteLine(" 31 Days here....");
                    break;
                case "Apr":
                case "Jun":
                case "Sep":
                case "Nov":
                    Console.WriteLine(" 30 Days here....");
                    break;
                case "Feb":
                    Console.WriteLine(" 28 Days here....");
                    break;
                default:
                    Console.WriteLine(" No idea ....");
                    break;
            }


        } // Switch(va){ case "cond": .... break; default: ... break; } Example

        static void divide2Numbers()
        {

            Console.Write(" Enter  a number :");
            int i = int.Parse(Console.ReadLine());
            Console.Write(" Enter another number:");
            int j = int.Parse(Console.ReadLine());
            // Happy Path - if everything goes fine 
            try
            {
                Console.WriteLine(" dividing 100 by 10 :: " + i / j);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                Console.WriteLine("\n After try{..}catch{...} in Finally Block");
            }
        }

        static void invokeAdd()
        {
            Console.WriteLine(" Sum of 22 & 44 " + add(22, 44));
            Console.WriteLine(" Sum of \"22\" & \"44\" " + add("22", "44"));
            Console.WriteLine(" Sum of 22.45 & 44.98 " + add(22.45f, 44.98f));
        }
        static void Main(string[] args) // Start here.....
        {

            /* Code to read command line arguments and access them within the program
            Console.Write(" Args :: ");
            foreach (String arg in args)
            {
                Console.Write(arg + " ");
            }*/


            //  divide2Numbers();


            /*arrayCalc();
            printArray();
            monthDays();
            mathTable(); */

            /*  WhileLoop();
              DoWhileLoop();
              ForLoop();
            */
            // playWithStrings();

            BankAccount ba = new BankAccount();
            Console.WriteLine(" Bank Account " + ba);
            BankAccount acc1 = new BankAccount(1,"John Doe",980.0f, 120.0f);
            Console.WriteLine(" Bank Account " + acc1 );

            Console.WriteLine("\n\t\t Current Balance :" + acc1.checkBalance());
            Console.WriteLine("\n\t\t Withdraw 250 : " + acc1.withdraw(250.0f));
            Console.WriteLine("\n\t\t Current Balance :" + acc1.checkBalance());
            Console.WriteLine("\n\t\t Deposit 150 : " + acc1.deposit(150.0f));
            Console.WriteLine("\n\t\t Current Balance :" + acc1.checkBalance());

            SalaryAccount sa = new SalaryAccount();
            Console.WriteLine(" Salary Account : " + sa);


        } // End Here....

        static void Pretty()
        {
            Console.WriteLine("\n==============================================================================================================");
        }

        static void WhileLoop()
        {
            int i = 1;
            Pretty();
            Console.WriteLine(" while(cond) { ....}");
            Pretty();
            while (i <= 100)
            {
                Console.Write(" " + i);
                i++;
            }
            Pretty();
        }
        static void DoWhileLoop()
        {
            int i = 1;
            Pretty();
            Console.WriteLine("Do { ....} while(cond);");
            Pretty();
            do
            {
                Console.Write(" " + i);
                i++;
            } while (i <= 100);
            Pretty();
        }

        static void ForLoop()
        {
            Pretty();
            Console.WriteLine("for(init; cond; progression) {...}");
            Pretty();
            for (int i = 0; i <= 100; i++)
            {
                Console.Write(" " + i);
            }
            Pretty();
        }

        static void printArray()
        {
            int[] xAxis = { 1, 2, 3, 4, 5 };

            Console.WriteLine(" Array Length : " + xAxis.Length);
            for (int x = 0; x < xAxis.Length; x++)
            {
                Console.WriteLine(" xAxis[" + x + "] = " + xAxis[x]);
            }
        }

        static void arrayCalc()
        {
            int[] xAxis = { 1, 2, 3, 4, 5 };
            int[] yAxis = { 9, 8, 7, 6, 5 };

            foreach (int x in xAxis)
            {
                foreach (int y in yAxis)
                {
                    Console.WriteLine(x + " * " + y + " = " + x * y);
                }
            }
        }

        static void playWithStrings()
        {
            Console.Write(" Enter 1st String Value : ");
            String str1 = Console.ReadLine();
            Console.Write(" Enter 2nd String Value : ");
            String str2 = Console.ReadLine();

            Console.WriteLine($" Strings entered 1) {str1} and 2) {str2}");

            Console.WriteLine("Trimmed String " + str1.Trim() + " " + str2.Trim());
            Console.WriteLine("LowerCase String " + str1.ToLower() + " " + str2.ToLower());
            Console.WriteLine("UpperCase String " + str1.ToUpper() + " " + str2.ToUpper());

        }
    }
}



/*MLC 
 * 
 * 
 * 
 *          C# and Java 
 *          
 *          DataTypes :  User Data 
 *          
 *              empID - String 
 *              name - String
 *              takeHomeSalary - 2923.23 [decimal values] - float / double 
 *              DeskNo = int 
 * 
 *  if (cond) {....}
 *  
 *  else if  { ... }
 *  
 *  else {...}
 * 
 * for(init; cond; inc/dec) { ....}
*  
*  while(cond) { ...}
*  
*  do { ...} while(cond}
*  
*  
*  Switch(var){
*   
*       case "cond":
*               .....
*               break;
*               
*       default:
*              .....
*              break;
*   }
 * 
 */

// Single Line Comment 