﻿using System;

public class BankAccount
{

	private int accNo;
	private String accHName;
	private float balance;
	private float minBalance;
	public BankAccount()
	{
        Console.WriteLine(" Zero Arg Constructor");
	}

	public BankAccount(int no, String name, float bal, float minBal) : this() {
		
		accNo = no;
		accHName = name;
		balance = bal;
		minBalance = minBal;

		Console.WriteLine(" Four Arg Constructor");
	}

	public override String ToString() {
		return ("\n\t\t AccNumber : " + accNo + ",\n\t\t Account Holder Name : " + accHName + ",\n\t\t Account Balance : " +
			balance + ",\n\t\t Account Min Balance Requirement : " + minBalance);
	}

	public float withdraw(float wdAmount) {
		balance -= wdAmount;
		return balance;
	}public float deposit(float amtCredited) {
		balance += amtCredited;
		return balance;
	}public float checkBalance() {
		return balance;
	}
}
